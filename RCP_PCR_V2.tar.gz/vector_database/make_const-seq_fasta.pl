#!/usr/bin/perl -w

use strict;
use Data::Dumper;

my $file = shift;

my $primers;
open FILE, $file;
while(<FILE>){
    chomp;
    my @array = split /\,/,$_; #/;
    if($#array>0){
	$primers->{$array[0]} = $array[1];
    }
}
close FILE;

while(my($key,$seq) = each %$primers){
    print ">$key\n$seq\n";

    my $comp = reverse $seq;
    $comp =~ tr/ATGCatgc/TACGtacg/;

    print ">c$key\n$comp\n";
}
